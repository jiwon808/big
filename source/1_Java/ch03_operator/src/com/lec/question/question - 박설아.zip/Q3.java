package com.lec.question;

public class Q3 {
	public static void main(String[] args) {
		int n1 = 3, n2 = 7;
		System.out.println(n1==n2 ? "O" : "X");
		System.out.println(n1>n2 ? "O" : "X");
	}
}
